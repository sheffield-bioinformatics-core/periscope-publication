_program = "periscope"
__version__ = "0.0.8a"

